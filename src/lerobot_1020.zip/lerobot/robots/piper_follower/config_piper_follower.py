#!/usr/bin/env python

# Copyright 2025 The HuggingFace Inc. team. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from dataclasses import dataclass, field

from lerobot.cameras import CameraConfig
from lerobot.cameras.opencv import OpenCVCameraConfig

from ..config import RobotConfig

@RobotConfig.register_subclass("piper_follower")
@dataclass
class PIPERFollowerConfig(RobotConfig):
    #cameras: dict[str, CameraConfig] = field(default_factory=dict)
    # # cameras
    cameras: dict[str, CameraConfig] = field(
        default_factory=lambda: {
            "top": OpenCVCameraConfig(
                index_or_path="/dev/video_top",
                fps=30,
                width=480,
                height=640,
                rotation=90,  # 无旋转（可按需调整 90/180/270）
            ),
            "wrist": OpenCVCameraConfig(
                index_or_path="/dev/video_wrist",
                fps=30,
                width=640,
                height=480,
                rotation=0,
            ),
            "down": OpenCVCameraConfig(
                index_or_path="/dev/video_down",
                fps=30,
                width=640,
                height=480,
                rotation=0,
            ),
        }
    )
    # EMA on teleop targets before JointCtrl: smaller = smoother, more lag. 1.0 = off.
    teleop_joint_alpha: float = 0.25
    teleop_gripper_alpha: float = 0.5
